-- Run this in your Supabase SQL Editor

CREATE TABLE IF NOT EXISTS users (
  discord_id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  avatar_url TEXT,
  wins INT DEFAULT 0,
  losses INT DEFAULT 0,
  uno_calls INT DEFAULT 0,
  elo_rating INT DEFAULT 1000,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_badges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  discord_id TEXT REFERENCES users(discord_id) ON DELETE CASCADE,
  badge_slug TEXT NOT NULL,
  badge_name TEXT NOT NULL,
  awarded_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(discord_id, badge_slug)
);

CREATE TABLE IF NOT EXISTS matches (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  room_code TEXT NOT NULL,
  winner_discord_id TEXT REFERENCES users(discord_id),
  mode TEXT DEFAULT 'ranked',
  player_count INT NOT NULL,
  played_at TIMESTAMPTZ DEFAULT NOW()
);

-- Atomic RPC helper to update ELO and W/L records after a Ranked match
CREATE OR REPLACE FUNCTION update_player_stats(
  p_discord_id TEXT,
  p_username TEXT,
  p_avatar TEXT,
  p_won BOOLEAN,
  p_elo_delta INT
) RETURNS VOID AS $$
BEGIN
  INSERT INTO users (discord_id, username, avatar_url, wins, losses, elo_rating)
  VALUES (
    p_discord_id,
    p_username,
    p_avatar,
    CASE WHEN p_won THEN 1 ELSE 0 END,
    CASE WHEN p_won THEN 0 ELSE 1 END,
    GREATEST(100, 1000 + p_elo_delta)
  )
  ON CONFLICT (discord_id) DO UPDATE SET
    username = EXCLUDED.username,
    avatar_url = COALESCE(EXCLUDED.avatar_url, users.avatar_url),
    wins = users.wins + (CASE WHEN p_won THEN 1 ELSE 0 END),
    losses = users.losses + (CASE WHEN p_won THEN 0 ELSE 1 END),
    elo_rating = GREATEST(100, users.elo_rating + p_elo_delta);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE VIEW leaderboard AS
SELECT
  discord_id,
  username,
  avatar_url,
  wins,
  losses,
  elo_rating,
  ROUND((wins::NUMERIC / NULLIF(wins + losses, 0)) * 100, 1) AS win_rate
FROM users
WHERE (wins + losses) > 0
ORDER BY elo_rating DESC, wins DESC
LIMIT 100;
