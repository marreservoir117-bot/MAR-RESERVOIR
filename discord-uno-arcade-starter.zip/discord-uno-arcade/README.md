# Discord Uno Arcade (Web + Discord Activity Starter)

A full-stack multiplayer Uno-style card game built with **Next.js**, **Node.js + Socket.io**, **Discord OAuth2**, **Discord Embedded App SDK (Activities)**, and **Supabase (PostgreSQL)**.

## Project Structure
- `client/` — Next.js frontend with Lobby UI, Live Uno Table, Turn Timer, Leaderboard, Discord OAuth2, and Discord Activity SDK integration.
- `server/` — Authoritative Node.js + Socket.io multiplayer server, Uno rules & bot engine, and Discord slash-command bot (`/play`).
- `supabase/schema.sql` — PostgreSQL schema for Discord user profiles, ELO rankings, badges, and match history.

## Quick Start

### 1. Database Setup (Supabase)
1. Create a free project at https://supabase.com.
2. Open the **SQL Editor** and run `supabase/schema.sql`.

### 2. Discord Developer Portal Setup
1. Create an application at https://discord.com/developers/applications.
2. Under **OAuth2**, add redirect URL `http://localhost:3000/api/auth/callback/discord` and copy your `Client ID` and `Client Secret`.
3. Under **Bot**, create a bot and copy the `Bot Token` (optional, for `/play` slash commands).
4. Under **Activities -> URL Mappings**, map `/` to your deployed HTTPS frontend URL when launching as a Discord Voice Channel Activity.

### 3. Start the Game Server
```bash
cd server
cp .env.example .env
npm install
npm start
```

### 4. Start the Next.js Frontend
```bash
cd client
cp .env.example .env.local
npm install
npm run dev
```
