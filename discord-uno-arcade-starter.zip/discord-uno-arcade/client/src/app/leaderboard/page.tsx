import { createClient } from "@supabase/supabase-js";
import Link from "next/link";

export const revalidate = 30;

export default async function LeaderboardPage() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  let players: any[] = [];
  if (supabaseUrl && supabaseKey) {
    const supabase = createClient(supabaseUrl, supabaseKey);
    const { data } = await supabase.from("leaderboard").select("*");
    players = data || [];
  }

  return (
    <div className="min-h-screen bg-[#0d0a0e] text-white p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-pink-400">🏆 Rankings</span>
            <h1 className="text-4xl font-extrabold mt-1">
              Season <span className="text-pink-500">Leaderboard</span>
            </h1>
          </div>
          <Link href="/" className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-sm font-bold">
            ← Back to Play
          </Link>
        </div>

        <div className="bg-[#18121a] border border-white/10 rounded-2xl overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-black/40 text-xs uppercase text-gray-400 border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4">Rank</th>
                <th className="py-3.5 px-4">Discord Player</th>
                <th className="py-3.5 px-4 text-right">ELO</th>
                <th className="py-3.5 px-4 text-right">W / L</th>
                <th className="py-3.5 px-4 text-right">Win %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {players.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-400">
                    No ranked matches played yet. Host a Ranked room to claim #1!
                  </td>
                </tr>
              ) : (
                players.map((p: any, idx: number) => (
                  <tr key={p.discord_id} className="hover:bg-white/5 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-pink-400">#{idx + 1}</td>
                    <td className="py-3.5 px-4 flex items-center gap-3 font-semibold">
                      <img
                        src={p.avatar_url || "https://cdn.discordapp.com/embed/avatars/0.png"}
                        alt={p.username}
                        className="w-7 h-7 rounded-full"
                      />
                      {p.username}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold">{p.elo_rating}</td>
                    <td className="py-3.5 px-4 text-right text-gray-300">
                      {p.wins}W - {p.losses}L
                    </td>
                    <td className="py-3.5 px-4 text-right text-emerald-400 font-semibold">
                      {p.win_rate ?? 0}%
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
