"use client";
import React, { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { useSession, signIn, signOut } from "next-auth/react";
import Link from "next/link";
import UnoTable from "../components/UnoTable";
import { initDiscordActivity } from "../lib/discordActivity";

export default function HomePage() {
  const { data: session } = useSession();
  const socketRef = useRef<Socket | null>(null);

  const [activityUser, setActivityUser] = useState<any>(null);
  const [gameState, setGameState] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState<string>("");

  // Practice vs Bots
  const [botCount, setBotCount] = useState<number>(2);
  const [botSkill, setBotSkill] = useState<string>("Normal");

  // Private Room
  const [seats, setSeats] = useState<number>(4);
  const [turnTimer, setTurnTimer] = useState<number>(20);
  const [isRanked, setIsRanked] = useState<boolean>(false);
  const [joinCode, setJoinCode] = useState<string>("");

  const activeUser = activityUser || (session?.user ? {
    id: (session.user as any).id,
    username: session.user.name,
    avatar: session.user.image,
  } : { id: null, username: "Guest", avatar: null });

  useEffect(() => {
    initDiscordActivity().then((u) => {
      if (u) setActivityUser(u);
    }).catch(console.error);

    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:4000");
    socketRef.current = socket;

    socket.on("game_state", (state) => {
      setErrorMsg("");
      setGameState(state);
    });

    socket.on("error_message", (msg) => setErrorMsg(msg));

    return () => {
      socket.disconnect();
    };
  }, []);

  if (gameState && socketRef.current) {
    return (
      <UnoTable
        gameState={gameState}
        myId={socketRef.current.id}
        onPlayCard={(cardId: string, chosenColor: string | null) =>
          socketRef.current?.emit("play_card", { code: gameState.code, cardId, chosenColor })
        }
        onDrawCard={() => socketRef.current?.emit("draw_card", { code: gameState.code })}
        onCallUno={() => socketRef.current?.emit("call_uno", { code: gameState.code })}
        onCatchUno={(targetId: string) =>
          socketRef.current?.emit("catch_uno", { code: gameState.code, targetId })
        }
        onStartPrivateRoom={(fillWithBots: boolean) =>
          socketRef.current?.emit("start_private_room", { code: gameState.code, fillWithBots })
        }
        onLeaveRoom={() => setGameState(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0d0a0e] text-white font-sans p-6">
      <header className="max-w-5xl mx-auto flex items-center justify-between py-4 border-b border-white/10">
        <div className="flex items-center gap-6">
          <span className="text-2xl font-black tracking-tight text-pink-500">DISCORD UNO</span>
          <nav className="hidden md:flex gap-5 text-sm text-gray-300">
            <Link href="/" className="text-white font-semibold">Play</Link>
            <Link href="/leaderboard" className="hover:text-white">Leaderboard</Link>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          {session?.user ? (
            <div className="flex items-center gap-3">
              {session.user.image && (
                <img src={session.user.image} alt="" className="w-7 h-7 rounded-full" />
              )}
              <span className="text-sm font-semibold">{session.user.name}</span>
              <button onClick={() => signOut()} className="text-xs text-gray-400 hover:text-white underline">
                Sign out
              </button>
            </div>
          ) : (
            <button
              onClick={() => signIn("discord")}
              className="px-4 py-2 text-xs font-bold bg-[#5865F2] hover:bg-[#4752C4] rounded-lg"
            >
              Sign in with Discord
            </button>
          )}
        </div>
      </header>

      <main className="max-w-3xl mx-auto mt-10 space-y-6">
        {errorMsg && (
          <div className="bg-rose-500/20 border border-rose-500 text-rose-200 px-4 py-3 rounded-xl text-sm">
            {errorMsg}
          </div>
        )}

        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-pink-400">🃏 Casual & Ranked</span>
          <h1 className="text-4xl font-extrabold mt-1">
            Play <span className="text-pink-500">any time</span>
          </h1>
          <p className="text-gray-400 text-sm mt-2">
            Practice against bots or set up a private room for your Discord server.
          </p>
        </div>

        {/* Practice vs Bots */}
        <section className="bg-[#18121a] border border-white/10 rounded-2xl p-6 space-y-5">
          <div>
            <h2 className="text-xl font-bold">🤖 Practice vs bots</h2>
            <p className="text-xs text-gray-400">Warm up before a tournament. Starts instantly.</p>
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-gray-400">Bots</label>
            <div className="grid grid-cols-4 gap-2 mt-2">
              {[1, 2, 3, 5].map((num) => (
                <button
                  key={num}
                  onClick={() => setBotCount(num)}
                  className={`py-2.5 rounded-xl font-bold text-sm transition ${
                    botCount === num ? "bg-pink-500 text-white" : "bg-black/40 text-gray-300"
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-gray-400">Bot Skill</label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {["Chill", "Normal", "Savage"].map((skill) => (
                <button
                  key={skill}
                  onClick={() => setBotSkill(skill)}
                  className={`py-2.5 rounded-xl font-bold text-sm transition ${
                    botSkill === skill ? "bg-pink-500 text-white" : "bg-black/40 text-gray-300"
                  }`}
                >
                  {skill}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={() =>
              socketRef.current?.emit("start_bot_game", { user: activeUser, botCount, botSkill })
            }
            className="w-full py-3 rounded-xl bg-pink-500 hover:bg-pink-600 font-bold text-sm transition"
          >
            ▶ Play now
          </button>
        </section>

        {/* Private Room */}
        <section className="bg-[#18121a] border border-white/10 rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">🎟 Private room</h2>
              <p className="text-xs text-gray-400">Get a code, send it in Discord, play together.</p>
            </div>
            <label className="flex items-center gap-2 text-xs font-bold cursor-pointer">
              <input
                type="checkbox"
                checked={isRanked}
                onChange={(e) => setIsRanked(e.target.checked)}
                className="accent-pink-500"
              />
              Ranked Match (ELO)
            </label>
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-gray-400">Seats</label>
            <div className="grid grid-cols-6 gap-2 mt-2">
              {[2, 3, 4, 6, 8, 10].map((s) => (
                <button
                  key={s}
                  onClick={() => setSeats(s)}
                  className={`py-2 rounded-xl font-bold text-sm ${
                    seats === s ? "bg-pink-500 text-white" : "bg-black/40 text-gray-300"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-gray-400">Seconds per turn</label>
            <div className="grid grid-cols-4 gap-2 mt-2">
              {[15, 20, 30, 45].map((sec) => (
                <button
                  key={sec}
                  onClick={() => setTurnTimer(sec)}
                  className={`py-2 rounded-xl font-bold text-sm ${
                    turnTimer === sec ? "bg-pink-500 text-white" : "bg-black/40 text-gray-300"
                  }`}
                >
                  {sec}s
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={() =>
              socketRef.current?.emit("create_room", {
                user: activeUser,
                seats,
                turnSeconds: turnTimer,
                botSkill,
                isRanked,
              })
            }
            className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/15 font-bold text-sm transition"
          >
            ＋ Create room
          </button>
        </section>

        {/* Join with a code */}
        <section className="bg-[#18121a] border border-white/10 rounded-2xl p-6 space-y-4">
          <div>
            <h2 className="text-xl font-bold">🔑 Join with a code</h2>
            <p className="text-xs text-gray-400">A friend posted a room code in Discord? Type it in.</p>
          </div>
          <div className="flex gap-3">
            <input
              type="text"
              placeholder="UNO-XXXX"
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value)}
              className="flex-1 bg-black/50 border border-white/10 rounded-xl px-4 py-2.5 text-sm uppercase tracking-wider focus:outline-none focus:border-pink-500"
            />
            <button
              onClick={() =>
                socketRef.current?.emit("join_room", { code: joinCode, user: activeUser })
              }
              className="px-6 py-2.5 rounded-xl bg-pink-500 hover:bg-pink-600 font-bold text-sm"
            >
              Join
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}
