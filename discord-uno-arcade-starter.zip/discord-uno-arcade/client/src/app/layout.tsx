import "./globals.css";
import { Providers } from "../components/Providers";

export const metadata = {
  title: "Discord Uno Arcade",
  description: "Multiplayer Uno for Discord communities",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
