"use client";
import React, { useEffect, useState } from "react";

export function TurnTimer({ deadline, totalSeconds }: { deadline?: number; totalSeconds: number }) {
  const [secondsLeft, setSecondsLeft] = useState<number>(totalSeconds);

  useEffect(() => {
    if (!deadline) return;
    const interval = setInterval(() => {
      const remaining = Math.max(0, (deadline - Date.now()) / 1000);
      setSecondsLeft(remaining);
    }, 100);
    return () => clearInterval(interval);
  }, [deadline]);

  if (!deadline) return null;
  const pct = Math.min(100, (secondsLeft / totalSeconds) * 100);

  return (
    <div className="w-full max-w-md mx-auto space-y-1">
      <div className="flex justify-between text-[11px] font-mono text-gray-400">
        <span>TURN TIMER</span>
        <span className={secondsLeft <= 5 ? "text-rose-500 font-bold" : "text-white"}>
          {Math.ceil(secondsLeft)}s
        </span>
      </div>
      <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
        <div
          className={`h-full transition-all duration-100 ${
            secondsLeft <= 5 ? "bg-rose-500" : "bg-pink-500"
          }`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
