"use client";
import React, { useState } from "react";
import { TurnTimer } from "./TurnTimer";

const COLOR_STYLES: Record<string, string> = {
  red: "bg-rose-600 border-rose-400 text-white",
  blue: "bg-sky-600 border-sky-400 text-white",
  green: "bg-emerald-600 border-emerald-400 text-white",
  yellow: "bg-amber-400 border-amber-200 text-black",
  wild: "bg-gradient-to-br from-rose-500 via-amber-400 to-sky-500 border-white text-white",
};

export default function UnoTable({
  gameState,
  myId,
  onPlayCard,
  onDrawCard,
  onCallUno,
  onCatchUno,
  onStartPrivateRoom,
  onLeaveRoom,
}: any) {
  const [pendingWildCardId, setPendingWildCardId] = useState<string | null>(null);

  // Waiting Room Lobby before host starts
  if (gameState.status === "waiting") {
    const isHost = gameState.hostId === myId;
    return (
      <div className="min-h-screen bg-[#0d0a0e] text-white flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-[#18121a] border border-white/10 rounded-3xl p-8 space-y-6 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-pink-400">
            🎟 Private Lobby
          </span>
          <h2 className="text-3xl font-black font-mono text-pink-500">{gameState.code}</h2>
          <p className="text-xs text-gray-400">
            Share this code in Discord. Seats: {gameState.players.length} / {gameState.maxSeats}
          </p>
          <div className="space-y-2 text-left">
            {gameState.players.map((p: any) => (
              <div key={p.id} className="bg-black/40 px-4 py-2.5 rounded-xl flex justify-between text-sm">
                <span className="font-semibold">{p.username}</span>
                <span className="text-xs text-pink-400">{p.id === gameState.hostId ? "HOST" : "READY"}</span>
              </div>
            ))}
          </div>
          {isHost ? (
            <button
              onClick={() => onStartPrivateRoom(true)}
              className="w-full py-3 rounded-xl bg-pink-500 hover:bg-pink-600 font-bold text-sm"
            >
              ▶ Start Match (Fill empty seats with Bots)
            </button>
          ) : (
            <p className="text-xs text-gray-400 animate-pulse">Waiting for host to start...</p>
          )}
          <button onClick={onLeaveRoom} className="text-xs text-gray-500 hover:text-white">
            Leave Room
          </button>
        </div>
      </div>
    );
  }

  const me = gameState.players.find((p: any) => p.id === myId);
  const opponents = gameState.players.filter((p: any) => p.id !== myId);
  const isMyTurn = gameState.players[gameState.turnIndex]?.id === myId;

  const handleCardClick = (card: any) => {
    if (!isMyTurn) return;
    if (card.color === "wild") {
      setPendingWildCardId(card.id);
    } else {
      onPlayCard(card.id, null);
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0a0e] text-white flex flex-col justify-between p-6 select-none">
      {/* Top Bar */}
      <div className="max-w-5xl w-full mx-auto space-y-5">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center gap-3">
            <span className="font-mono bg-white/5 px-3 py-1.5 rounded-lg border border-white/10">
              ROOM: <strong className="text-pink-400">{gameState.code}</strong>
            </span>
            <button onClick={onLeaveRoom} className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10">
              ← Lobby
            </button>
          </div>
          <span>
            Direction: <strong>{gameState.direction === 1 ? "Clockwise ↻" : "Counter-Clockwise ↺"}</strong>
          </span>
        </div>

        {/* Opponents */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {opponents.map((opp: any) => {
            const active = gameState.players[gameState.turnIndex]?.id === opp.id;
            return (
              <div
                key={opp.id}
                className={`p-4 rounded-2xl border transition ${
                  active ? "bg-pink-500/15 border-pink-500" : "bg-[#18121a] border-white/10"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-sm truncate">{opp.username}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-black/50 font-mono shrink-0">
                    {opp.cardCount} 🃏
                  </span>
                </div>
                {opp.cardCount === 1 && opp.calledUno && (
                  <span className="inline-block mt-2 text-[10px] font-black uppercase bg-pink-500 text-white px-2 py-0.5 rounded">
                    UNO CALLED!
                  </span>
                )}
                {opp.cardCount === 1 && !opp.calledUno && (
                  <button
                    onClick={() => onCatchUno(opp.id)}
                    className="mt-2 w-full py-1 text-[11px] font-black uppercase bg-amber-500 hover:bg-amber-400 text-black rounded-lg animate-bounce"
                  >
                    🚨 Catch! (+2 Penalty)
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Center Table */}
      <div className="flex flex-col items-center justify-center my-6 space-y-4">
        {gameState.winner ? (
          <div className="text-center bg-[#18121a] border border-pink-500 p-8 rounded-3xl space-y-4">
            <h2 className="text-3xl font-black text-pink-500">🏆 {gameState.winner} Wins!</h2>
            <button
              onClick={onLeaveRoom}
              className="px-6 py-2.5 rounded-xl bg-pink-500 hover:bg-pink-600 font-bold text-sm"
            >
              Back to Lobby
            </button>
          </div>
        ) : (
          <>
            <TurnTimer deadline={gameState.turnDeadline} totalSeconds={gameState.turnSeconds} />
            <div className="flex items-center gap-6">
              <button
                onClick={onDrawCard}
                disabled={!isMyTurn}
                className={`w-28 h-40 rounded-2xl border-2 border-white/20 bg-[#1c1520] flex flex-col items-center justify-center shadow-xl transition ${
                  isMyTurn ? "hover:scale-105 cursor-pointer ring-2 ring-pink-500/50" : "opacity-60"
                }`}
              >
                <span className="text-xl font-black text-pink-500 text-center px-2">
                  {gameState.pendingDraw > 0 ? `TAKE +${gameState.pendingDraw}` : "DRAW"}
                </span>
                <span className="text-[11px] text-gray-400 mt-1">
                  {gameState.pendingDraw > 0 ? "or stack +2 / +4" : "+1 Card"}
                </span>
              </button>

              <div
                className={`w-28 h-40 rounded-2xl border-4 flex flex-col items-center justify-center shadow-2xl ${
                  COLOR_STYLES[gameState.activeColor] || COLOR_STYLES.wild
                }`}
              >
                <span className="text-3xl font-black uppercase">{gameState.topCard.value}</span>
                <span className="text-[10px] uppercase tracking-widest mt-2 opacity-80">
                  {gameState.activeColor}
                </span>
              </div>
            </div>

            <div className="text-sm font-bold">
              {isMyTurn ? (
                <span className="text-pink-400 animate-pulse">Your turn — play a card or draw!</span>
              ) : (
                <span className="text-gray-400">
                  Waiting for {gameState.players[gameState.turnIndex]?.username}...
                </span>
              )}
            </div>
          </>
        )}
      </div>

      {/* Wild Color Modal */}
      {pendingWildCardId && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50">
          <div className="bg-[#18121a] border border-white/15 p-6 rounded-2xl space-y-4 text-center">
            <h3 className="font-bold text-lg">Choose a Color</h3>
            <div className="grid grid-cols-2 gap-3">
              {["red", "blue", "green", "yellow"].map((color) => (
                <button
                  key={color}
                  onClick={() => {
                    onPlayCard(pendingWildCardId, color);
                    setPendingWildCardId(null);
                  }}
                  className={`px-6 py-3 rounded-xl font-bold uppercase text-sm ${COLOR_STYLES[color]}`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Player Hand */}
      <div className="max-w-5xl w-full mx-auto">
        {me?.hand?.length <= 2 && !me?.calledUno && !gameState.winner && (
          <div className="flex justify-center mb-4">
            <button
              onClick={onCallUno}
              className="px-8 py-3 rounded-full bg-gradient-to-r from-pink-500 to-amber-500 font-black uppercase tracking-wider text-sm shadow-lg hover:scale-105 transition"
            >
              📣 Call UNO!
            </button>
          </div>
        )}
        <div className="flex flex-wrap justify-center gap-2.5">
          {me?.hand?.map((card: any) => (
            <button
              key={card.id}
              onClick={() => handleCardClick(card)}
              disabled={!isMyTurn}
              className={`w-20 h-32 rounded-xl border-2 flex flex-col items-center justify-center font-black text-xl shadow-lg transition transform ${
                COLOR_STYLES[card.color]
              } ${isMyTurn ? "hover:-translate-y-3 cursor-pointer" : "opacity-70"}`}
            >
              <span className="uppercase">{card.value}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
