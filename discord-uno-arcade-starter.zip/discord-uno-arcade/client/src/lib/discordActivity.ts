import { DiscordSDK } from "@discord/embedded-app-sdk";

export async function initDiscordActivity() {
  // Only initialize if running inside Discord's Activity iframe
  if (typeof window === "undefined" || !window.location.search.includes("frame_id")) {
    return null;
  }

  const clientId = process.env.NEXT_PUBLIC_DISCORD_CLIENT_ID!;
  const discordSdk = new DiscordSDK(clientId);
  await discordSdk.ready();

  const { code } = await discordSdk.commands.authorize({
    client_id: clientId,
    response_type: "code",
    state: "",
    prompt: "none",
    scope: ["identify"],
  });

  const socketUrl = process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:4000";
  const tokenRes = await fetch(`${socketUrl}/api/discord-token`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code }),
  });
  const { access_token } = await tokenRes.json();

  const auth = await discordSdk.commands.authenticate({ access_token });
  return {
    id: auth.user.id,
    username: auth.user.username,
    avatar: auth.user.avatar
      ? `https://cdn.discordapp.com/avatars/${auth.user.id}/${auth.user.avatar}.png`
      : `https://cdn.discordapp.com/embed/avatars/0.png`,
    instanceId: discordSdk.instanceId,
  };
}
