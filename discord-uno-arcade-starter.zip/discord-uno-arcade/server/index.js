require("dotenv").config();
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const { createClient } = require("@supabase/supabase-js");
const {
  createDeck,
  shuffle,
  isValidMove,
  chooseBotMove,
  pickBestWildColor,
} = require("./gameEngine");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const supabase =
  process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
    ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY)
    : null;

const rooms = new Map();

function generateRoomCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `UNO-${code}`;
}

function sanitizeStateForPlayer(room, playerId) {
  return {
    code: room.code,
    hostId: room.hostId,
    status: room.status,
    isRanked: room.isRanked,
    maxSeats: room.maxSeats,
    topCard: room.topCard,
    activeColor: room.activeColor,
    direction: room.direction,
    turnIndex: room.turnIndex,
    turnSeconds: room.turnSeconds,
    turnDeadline: room.turnDeadline,
    pendingDraw: room.pendingDraw,
    winner: room.winner,
    players: room.players.map((p) => ({
      id: p.id,
      username: p.username,
      avatar: p.avatar,
      isBot: p.isBot,
      calledUno: p.calledUno,
      cardCount: p.hand.length,
      hand: p.id === playerId ? p.hand : undefined,
    })),
  };
}

function broadcastRoom(room) {
  for (const player of room.players) {
    if (!player.isBot) {
      io.to(player.id).emit("game_state", sanitizeStateForPlayer(room, player.id));
    }
  }
}

function drawCards(room, player, count) {
  for (let i = 0; i < count; i++) {
    if (room.deck.length === 0 && room.discardPile.length > 1) {
      const top = room.discardPile.pop();
      room.deck = shuffle(room.discardPile);
      room.discardPile = [top];
    }
    if (room.deck.length > 0) {
      player.hand.push(room.deck.pop());
    }
  }
}

function advanceTurn(room, step = 1) {
  const len = room.players.length;
  room.turnIndex = (room.turnIndex + step * room.direction + len * 10) % len;
}

function startTurnTimer(room) {
  if (room.timerHandle) clearTimeout(room.timerHandle);
  if (room.status !== "playing") return;

  const currentPlayer = room.players[room.turnIndex];
  if (!currentPlayer || currentPlayer.isBot) {
    room.turnDeadline = null;
    return;
  }

  const durationMs = (room.turnSeconds || 20) * 1000;
  room.turnDeadline = Date.now() + durationMs;
  broadcastRoom(room);

  room.timerHandle = setTimeout(() => {
    const drawAmount = room.pendingDraw > 0 ? room.pendingDraw : 1;
    drawCards(room, currentPlayer, drawAmount);
    room.pendingDraw = 0;
    currentPlayer.calledUno = false;

    advanceTurn(room, 1);
    broadcastRoom(room);
    startTurnTimer(room);
    triggerBotIfNeeded(room);
  }, durationMs);
}

async function recordRankedMatch(room, winner) {
  if (!supabase) return;
  const humanPlayers = room.players.filter((p) => !p.isBot && p.discordId);
  for (const p of humanPlayers) {
    const isWinner = p.discordId === winner.discordId;
    await supabase.rpc("update_player_stats", {
      p_discord_id: p.discordId,
      p_username: p.username,
      p_avatar: p.avatar,
      p_won: isWinner,
      p_elo_delta: isWinner ? 25 : -12,
    });
  }
  await supabase.from("matches").insert({
    room_code: room.code,
    winner_discord_id: winner.discordId || null,
    mode: "ranked",
    player_count: room.players.length,
  });
}

function processMove(room, playerIndex, card, chosenColor) {
  const player = room.players[playerIndex];
  player.hand = player.hand.filter((c) => c.id !== card.id);
  room.discardPile.push(card);
  room.topCard = card;
  room.activeColor = card.color === "wild" ? chosenColor || "red" : card.color;

  if (player.hand.length !== 1) {
    player.calledUno = false;
  }

  if (player.hand.length === 0) {
    if (room.timerHandle) clearTimeout(room.timerHandle);
    room.status = "finished";
    room.winner = player.username;
    room.turnDeadline = null;
    broadcastRoom(room);
    if (room.isRanked) {
      recordRankedMatch(room, player).catch(console.error);
    }
    return;
  }

  let step = 1;
  if (card.value === "reverse") {
    if (room.players.length === 2) step = 2;
    else room.direction *= -1;
  } else if (card.value === "skip") {
    step = 2;
  } else if (card.value === "+2") {
    room.pendingDraw += 2;
  } else if (card.value === "+4") {
    room.pendingDraw += 4;
  }

  advanceTurn(room, step);
  broadcastRoom(room);
  startTurnTimer(room);
  triggerBotIfNeeded(room);
}

function triggerBotIfNeeded(room) {
  if (room.status !== "playing") return;
  const currentPlayer = room.players[room.turnIndex];
  if (!currentPlayer || !currentPlayer.isBot) return;

  setTimeout(() => {
    if (room.status !== "playing") return;
    const chosenCard = chooseBotMove(
      currentPlayer.hand,
      room.topCard,
      room.activeColor,
      currentPlayer.skill,
      room.pendingDraw
    );

    if (chosenCard) {
      if (currentPlayer.hand.length === 2) {
        const callChance =
          currentPlayer.skill === "Savage" ? 0.95 : currentPlayer.skill === "Normal" ? 0.6 : 0.25;
        currentPlayer.calledUno = Math.random() < callChance;
      }
      const wildColor = chosenCard.color === "wild" ? pickBestWildColor(currentPlayer.hand) : null;
      processMove(room, room.turnIndex, chosenCard, wildColor);
    } else {
      const drawAmount = room.pendingDraw > 0 ? room.pendingDraw : 1;
      drawCards(room, currentPlayer, drawAmount);
      room.pendingDraw = 0;
      currentPlayer.calledUno = false;
      advanceTurn(room, 1);
      broadcastRoom(room);
      startTurnTimer(room);
      triggerBotIfNeeded(room);
    }
  }, 1100);
}

function dealAndStart(room) {
  const deck = createDeck();
  for (const p of room.players) {
    p.hand = [];
    p.calledUno = false;
    for (let i = 0; i < 7; i++) p.hand.push(deck.pop());
  }
  let firstCard = deck.pop();
  while (firstCard.color === "wild") {
    deck.unshift(firstCard);
    firstCard = deck.pop();
  }
  room.deck = deck;
  room.discardPile = [firstCard];
  room.topCard = firstCard;
  room.activeColor = firstCard.color;
  room.direction = 1;
  room.turnIndex = 0;
  room.pendingDraw = 0;
  room.status = "playing";
  broadcastRoom(room);
  startTurnTimer(room);
  triggerBotIfNeeded(room);
}

// Discord Activity token exchange endpoint
app.post("/api/discord-token", async (req, res) => {
  try {
    const response = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_BOT_SECRET || process.env.DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code: req.body.code,
      }),
    });
    const data = await response.json();
    res.json({ access_token: data.access_token });
  } catch (err) {
    res.status(500).json({ error: "Token exchange failed" });
  }
});

io.on("connection", (socket) => {
  socket.on("start_bot_game", ({ user, botCount = 2, botSkill = "Normal" }) => {
    const code = generateRoomCode();
    const players = [
      {
        id: socket.id,
        discordId: user?.id || null,
        username: user?.username || "Guest",
        avatar: user?.avatar || null,
        isBot: false,
        calledUno: false,
        hand: [],
      },
    ];
    for (let i = 1; i <= botCount; i++) {
      players.push({
        id: `bot-${i}-${code}`,
        username: `Bot ${i} (${botSkill})`,
        isBot: true,
        skill: botSkill,
        calledUno: false,
        hand: [],
      });
    }
    const room = {
      code,
      hostId: socket.id,
      status: "waiting",
      isRanked: false,
      maxSeats: players.length,
      turnSeconds: 20,
      players,
    };
    rooms.set(code, room);
    socket.join(code);
    dealAndStart(room);
  });

  socket.on("create_room", ({ user, seats = 4, turnSeconds = 20, botSkill = "Normal", isRanked = false }) => {
    const code = generateRoomCode();
    const room = {
      code,
      hostId: socket.id,
      status: "waiting",
      isRanked,
      maxSeats: seats,
      turnSeconds,
      botSkill,
      players: [
        {
          id: socket.id,
          discordId: user?.id || null,
          username: user?.username || "Host",
          avatar: user?.avatar || null,
          isBot: false,
          calledUno: false,
          hand: [],
        },
      ],
    };
    rooms.set(code, room);
    socket.join(code);
    broadcastRoom(room);
  });

  socket.on("join_room", ({ code, user }) => {
    const cleanCode = (code || "").trim().toUpperCase();
    const room = rooms.get(cleanCode);
    if (!room) return socket.emit("error_message", "Room not found.");
    if (room.status !== "waiting") return socket.emit("error_message", "Game already in progress.");
    if (room.players.length >= room.maxSeats) return socket.emit("error_message", "Room is full.");

    room.players.push({
      id: socket.id,
      discordId: user?.id || null,
      username: user?.username || "Player",
      avatar: user?.avatar || null,
      isBot: false,
      calledUno: false,
      hand: [],
    });
    socket.join(cleanCode);
    broadcastRoom(room);
  });

  socket.on("start_private_room", ({ code, fillWithBots = true }) => {
    const room = rooms.get(code);
    if (!room || room.hostId !== socket.id) return;
    if (fillWithBots) {
      let botNum = 1;
      while (room.players.length < room.maxSeats) {
        room.players.push({
          id: `bot-${botNum++}-${code}`,
          username: `Bot ${botNum - 1}`,
          isBot: true,
          skill: room.botSkill || "Normal",
          calledUno: false,
          hand: [],
        });
      }
    }
    if (room.players.length >= 2) {
      dealAndStart(room);
    }
  });

  socket.on("play_card", ({ code, cardId, chosenColor }) => {
    const room = rooms.get(code);
    if (!room || room.status !== "playing") return;
    const playerIndex = room.players.findIndex((p) => p.id === socket.id);
    if (playerIndex !== room.turnIndex) return;

    const card = room.players[playerIndex].hand.find((c) => c.id === cardId);
    if (!card || !isValidMove(card, room.topCard, room.activeColor, room.pendingDraw)) return;

    processMove(room, playerIndex, card, chosenColor);
  });

  socket.on("draw_card", ({ code }) => {
    const room = rooms.get(code);
    if (!room || room.status !== "playing") return;
    const playerIndex = room.players.findIndex((p) => p.id === socket.id);
    if (playerIndex !== room.turnIndex) return;

    const player = room.players[playerIndex];
    const drawAmount = room.pendingDraw > 0 ? room.pendingDraw : 1;
    drawCards(room, player, drawAmount);
    room.pendingDraw = 0;
    player.calledUno = false;

    advanceTurn(room, 1);
    broadcastRoom(room);
    startTurnTimer(room);
    triggerBotIfNeeded(room);
  });

  socket.on("call_uno", ({ code }) => {
    const room = rooms.get(code);
    if (!room) return;
    const player = room.players.find((p) => p.id === socket.id);
    if (player && player.hand.length <= 2) {
      player.calledUno = true;
      broadcastRoom(room);
    }
  });

  socket.on("catch_uno", ({ code, targetId }) => {
    const room = rooms.get(code);
    if (!room) return;
    const target = room.players.find((p) => p.id === targetId);
    if (target && target.hand.length === 1 && !target.calledUno) {
      drawCards(room, target, 2);
      target.calledUno = false;
      broadcastRoom(room);
    }
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Discord Uno Server running on port ${PORT}`));
