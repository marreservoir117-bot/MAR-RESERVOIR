const COLORS = ["red", "blue", "green", "yellow"];
const VALUES = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "skip", "reverse", "+2"];

function createDeck() {
  const deck = [];
  for (const color of COLORS) {
    deck.push({ id: `${color}-0`, color, value: "0" });
    for (let i = 1; i < VALUES.length; i++) {
      deck.push({ id: `${color}-${VALUES[i]}-a`, color, value: VALUES[i] });
      deck.push({ id: `${color}-${VALUES[i]}-b`, color, value: VALUES[i] });
    }
  }
  for (let i = 0; i < 4; i++) {
    deck.push({ id: `wild-${i}`, color: "wild", value: "wild" });
    deck.push({ id: `wild4-${i}`, color: "wild", value: "+4" });
  }
  return shuffle(deck);
}

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function isValidMove(card, topCard, activeColor, pendingDraw = 0) {
  if (pendingDraw > 0) {
    if (topCard.value === "+2") return card.value === "+2" || card.value === "+4";
    if (topCard.value === "+4") return card.value === "+4";
  }
  if (card.color === "wild") return true;
  if (card.color === activeColor) return true;
  if (card.value === topCard.value) return true;
  return false;
}

function chooseBotMove(hand, topCard, activeColor, skill = "Normal", pendingDraw = 0) {
  const playable = hand.filter((c) => isValidMove(c, topCard, activeColor, pendingDraw));
  if (playable.length === 0) return null;

  if (skill === "Chill") {
    return playable[Math.floor(Math.random() * playable.length)];
  }

  if (skill === "Savage") {
    const priority = ["+4", "+2", "skip", "reverse", "wild"];
    for (const p of priority) {
      const found = playable.find((c) => c.value === p);
      if (found) return found;
    }
  }

  const nonWild = playable.filter((c) => c.color !== "wild");
  return nonWild.length > 0 ? nonWild[0] : playable[0];
}

function pickBestWildColor(hand) {
  const counts = { red: 0, blue: 0, green: 0, yellow: 0 };
  for (const card of hand) {
    if (counts[card.color] !== undefined) counts[card.color]++;
  }
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
}

module.exports = {
  createDeck,
  shuffle,
  isValidMove,
  chooseBotMove,
  pickBestWildColor,
};
