require("dotenv").config();
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require("discord.js");

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
  new SlashCommandBuilder()
    .setName("play")
    .setDescription("Create a private Uno room link for this Discord channel")
    .addIntegerOption((opt) =>
      opt.setName("seats").setDescription("Max seats (2-10)").setMinValue(2).setMaxValue(10)
    ),
].map((c) => c.toJSON());

client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_BOT_TOKEN);
  await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands });
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand() || interaction.commandName !== "play") return;
  const seats = interaction.options.getInteger("seats") || 4;
  const webUrl = process.env.PUBLIC_WEB_URL || "http://localhost:3000";

  await interaction.reply({
    content: `🃏 **${interaction.user.username}** is hosting a **${seats}-player** Uno match!\n👉 Launch Lobby: ${webUrl}`,
  });
});

client.login(process.env.DISCORD_BOT_TOKEN);
